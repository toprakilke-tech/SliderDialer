package com.example.sliderdialer

import android.content.res.ColorStateList
import android.graphics.Color
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.telecom.Call
import android.telecom.CallAudioState
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity

class CallActivity : AppCompatActivity() {

    private lateinit var nameView: TextView
    private lateinit var stateView: TextView
    private lateinit var muteButton: Button
    private lateinit var speakerButton: Button
    private lateinit var answerButton: Button
    private lateinit var endButton: Button

    private var muted = false
    private var speaker = false
    private var seenCall = false

    private val handler = Handler(Looper.getMainLooper())
    private val ticker = object : Runnable {
        override fun run() {
            update()
            handler.postDelayed(this, 1000)
        }
    }
    private val listener: () -> Unit = { update() }

    private fun dp(value: Int): Int = (value * resources.displayMetrics.density).toInt()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_HORIZONTAL
            fitsSystemWindows = true
            setPadding(dp(24), dp(48), dp(24), dp(32))
        }

        nameView = TextView(this).apply {
            textSize = 32f
            gravity = Gravity.CENTER
        }
        stateView = TextView(this).apply {
            textSize = 18f
            gravity = Gravity.CENTER
        }
        root.addView(nameView, LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
        root.addView(stateView, LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))

        // Pushes the buttons to the bottom of the screen.
        root.addView(View(this), LinearLayout.LayoutParams(0, 0, 1f))

        val toggles = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        muteButton = Button(this).apply {
            text = "Sessiz"
            setOnClickListener {
                muted = !muted
                CallManager.service?.setMuted(muted)
                text = if (muted) "Sesi aç" else "Sessiz"
            }
        }
        speakerButton = Button(this).apply {
            text = "Hoparlör"
            setOnClickListener {
                speaker = !speaker
                CallManager.service?.setAudioRoute(
                    if (speaker) CallAudioState.ROUTE_SPEAKER else CallAudioState.ROUTE_EARPIECE
                )
                text = if (speaker) "Kulaklık" else "Hoparlör"
            }
        }
        toggles.addView(muteButton, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        toggles.addView(speakerButton, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        root.addView(toggles, LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))

        val actions = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        endButton = Button(this).apply {
            textSize = 18f
            setTextColor(Color.WHITE)
            backgroundTintList = ColorStateList.valueOf(Color.rgb(200, 40, 40))
            setOnClickListener { CallManager.hangUp() }
        }
        answerButton = Button(this).apply {
            text = "Cevapla"
            textSize = 18f
            setTextColor(Color.WHITE)
            backgroundTintList = ColorStateList.valueOf(Color.rgb(46, 160, 67))
            setOnClickListener { CallManager.answer() }
        }
        actions.addView(endButton, LinearLayout.LayoutParams(0, dp(64), 1f))
        actions.addView(answerButton, LinearLayout.LayoutParams(0, dp(64), 1f))
        root.addView(actions, LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))

        setContentView(root)

        CallManager.addListener(listener)
        handler.post(ticker)
        // If no call shows up shortly after this screen opens, there is nothing to show.
        handler.postDelayed({ if (!seenCall) finish() }, 3000)
    }

    override fun onDestroy() {
        CallManager.removeListener(listener)
        handler.removeCallbacksAndMessages(null)
        super.onDestroy()
    }

    private fun update() {
        val call = CallManager.call
        if (call == null) {
            if (seenCall) finish()
            return
        }
        seenCall = true

        nameView.text = CallManager.displayName()
        val ringing = call.state == Call.STATE_RINGING
        answerButton.visibility = if (ringing) View.VISIBLE else View.GONE
        muteButton.visibility = if (ringing) View.GONE else View.VISIBLE
        speakerButton.visibility = if (ringing) View.GONE else View.VISIBLE
        endButton.text = if (ringing) "Reddet" else "Bitir"

        stateView.text = when (call.state) {
            Call.STATE_RINGING -> "Gelen arama"
            Call.STATE_DIALING, Call.STATE_CONNECTING -> "Aranıyor..."
            Call.STATE_ACTIVE -> duration(call)
            Call.STATE_HOLDING -> "Beklemede"
            Call.STATE_DISCONNECTING, Call.STATE_DISCONNECTED -> "Arama bitti"
            else -> ""
        }
    }

    private fun duration(call: Call): String {
        val start = call.details.connectTimeMillis
        if (start <= 0) return "Görüşme"
        val seconds = ((System.currentTimeMillis() - start) / 1000).coerceAtLeast(0)
        return String.format("%02d:%02d", seconds / 60, seconds % 60)
    }
}
