package com.example.sliderdialer

import android.telecom.Call
import android.telecom.VideoProfile

object CallManager {

    var call: Call? = null
        private set
    var service: CallService? = null

    private val listeners = ArrayList<() -> Unit>()

    private val callback = object : Call.Callback() {
        override fun onStateChanged(call: Call, state: Int) {
            notifyChanged()
        }

        override fun onDetailsChanged(call: Call, details: Call.Details) {
            notifyChanged()
        }
    }

    fun addListener(listener: () -> Unit) {
        listeners.add(listener)
    }

    fun removeListener(listener: () -> Unit) {
        listeners.remove(listener)
    }

    private fun notifyChanged() {
        listeners.toList().forEach { it() }
    }

    fun setCall(newCall: Call?) {
        call?.unregisterCallback(callback)
        call = newCall
        newCall?.registerCallback(callback)
        notifyChanged()
    }

    fun answer() {
        call?.answer(VideoProfile.STATE_AUDIO_ONLY)
    }

    // Rejects a ringing call, otherwise ends the call.
    fun hangUp() {
        val current = call ?: return
        if (current.state == Call.STATE_RINGING) {
            current.reject(false, null)
        } else {
            current.disconnect()
        }
    }

    fun number(): String = call?.details?.handle?.schemeSpecificPart ?: ""

    fun displayName(): String {
        val name = call?.details?.callerDisplayName
        return if (name.isNullOrEmpty()) number() else name
    }
}
