package com.example.sliderdialer

import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Intent
import android.os.Build
import android.telecom.Call
import android.telecom.InCallService
import androidx.core.app.NotificationCompat

class CallService : InCallService() {

    private val channelId = "incoming_calls"
    private val notificationId = 1

    // Remove the incoming-call notification as soon as the call is no longer ringing.
    private val stateListener: () -> Unit = {
        if (CallManager.call?.state != Call.STATE_RINGING) cancelNotification()
    }

    override fun onCreate() {
        super.onCreate()
        CallManager.addListener(stateListener)
    }

    override fun onDestroy() {
        CallManager.removeListener(stateListener)
        super.onDestroy()
    }

    override fun onCallAdded(call: Call) {
        super.onCallAdded(call)
        CallManager.service = this
        CallManager.setCall(call)
        if (call.state == Call.STATE_RINGING) {
            showIncomingNotification()
        } else {
            openCallScreen()
        }
    }

    override fun onCallRemoved(call: Call) {
        super.onCallRemoved(call)
        if (CallManager.call == call) {
            CallManager.setCall(null)
        }
        cancelNotification()
    }

    private fun openCallScreen() {
        try {
            startActivity(Intent(this, CallActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        } catch (e: Exception) {
            // The system may block starting a screen from the background. The notification path covers incoming calls.
        }
    }

    private fun showIncomingNotification() {
        val manager = getSystemService(NotificationManager::class.java)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            manager.createNotificationChannel(
                NotificationChannel(channelId, "Gelen aramalar", NotificationManager.IMPORTANCE_HIGH)
            )
        }
        val intent = Intent(this, CallActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        val pending = PendingIntent.getActivity(
            this, 0, intent, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        val notification = NotificationCompat.Builder(this, channelId)
            .setSmallIcon(android.R.drawable.sym_action_call)
            .setContentTitle("Gelen arama")
            .setContentText(CallManager.displayName())
            .setCategory(NotificationCompat.CATEGORY_CALL)
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .setOngoing(true)
            .setFullScreenIntent(pending, true)
            .setContentIntent(pending)
            .build()
        manager.notify(notificationId, notification)
    }

    private fun cancelNotification() {
        getSystemService(NotificationManager::class.java).cancel(notificationId)
    }
}
