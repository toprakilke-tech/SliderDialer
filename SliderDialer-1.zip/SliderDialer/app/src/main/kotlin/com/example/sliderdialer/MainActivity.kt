package com.example.sliderdialer

import android.Manifest
import android.app.role.RoleManager
import android.content.ActivityNotFoundException
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Typeface
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.telecom.TelecomManager
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.SeekBar
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {

    private val digitCount = 11
    private var number = ""
    private var sliderMode = false

    private lateinit var display: TextView
    private lateinit var modeButton: Button
    private lateinit var defaultButton: Button
    private lateinit var keypad: LinearLayout
    private lateinit var sliderScroll: ScrollView
    private val digitBars = ArrayList<SeekBar>()
    private val digitValues = ArrayList<TextView>()

    private val dialerRoleLauncher =
        registerForActivityResult(ActivityResultContracts.StartActivityForResult()) {
            updateDefaultButton()
        }

    private val callPermissionLauncher =
        registerForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
            if (granted) {
                placeCall()
            } else {
                toast("Arama izni verilmedi")
            }
        }

    private val notificationPermissionLauncher =
        registerForActivityResult(ActivityResultContracts.RequestPermission()) { }

    private fun dp(value: Int): Int = (value * resources.displayMetrics.density).toInt()

    private fun toast(message: String) {
        Toast.makeText(this, message, Toast.LENGTH_SHORT).show()
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            fitsSystemWindows = true
            setPadding(dp(16), dp(8), dp(16), dp(8))
        }

        display = TextView(this).apply {
            textSize = 28f
            typeface = Typeface.MONOSPACE
            gravity = Gravity.CENTER
        }
        root.addView(display, LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT, dp(64)))

        modeButton = Button(this).apply {
            setOnClickListener { toggleMode() }
        }
        root.addView(modeButton, LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))

        defaultButton = Button(this).apply {
            text = "Varsayılan arama uygulaması yap"
            setOnClickListener { requestDefaultDialer() }
        }
        root.addView(defaultButton, LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))

        val middle = FrameLayout(this)
        keypad = buildKeypad()
        sliderScroll = buildSliders()
        middle.addView(keypad, FrameLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))
        middle.addView(sliderScroll, FrameLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))
        root.addView(middle, LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f))

        val editRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        val backspace = Button(this).apply {
            text = "Sil"
            setOnClickListener {
                if (number.isNotEmpty()) {
                    number = number.dropLast(1)
                    render()
                }
            }
        }
        val clear = Button(this).apply {
            text = "Temizle"
            setOnClickListener {
                number = ""
                render()
            }
        }
        editRow.addView(backspace, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        editRow.addView(clear, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        root.addView(editRow, LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))

        val hintRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        val messageHint = TextView(this).apply {
            text = "< Mesaj için sola kaydır"
            textSize = 12f
            gravity = Gravity.START
        }
        val callHint = TextView(this).apply {
            text = "Aramak için sağa kaydır >"
            textSize = 12f
            gravity = Gravity.END
        }
        hintRow.addView(messageHint, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        hintRow.addView(callHint, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        root.addView(hintRow, LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))

        // Center is neutral: right end calls, left end sends a message.
        val action = SeekBar(this).apply {
            max = 100
            progress = 50
            setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(seekBar: SeekBar?, progress: Int, fromUser: Boolean) {}
                override fun onStartTrackingTouch(seekBar: SeekBar?) {}
                override fun onStopTrackingTouch(seekBar: SeekBar?) {
                    val value = seekBar?.progress ?: 50
                    seekBar?.progress = 50
                    when {
                        value >= 95 -> startCall()
                        value <= 5 -> startMessage()
                    }
                }
            })
        }
        root.addView(action, LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT, dp(56)))

        setContentView(root)

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU &&
            checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) {
            notificationPermissionLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
        }

        readNumberFromIntent(intent)
        applyMode()
        render()
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        readNumberFromIntent(intent)
        render()
    }

    override fun onResume() {
        super.onResume()
        updateDefaultButton()
    }

    // Other apps can open this screen with a tel: link; show that number.
    private fun readNumberFromIntent(intent: Intent?) {
        val data = intent?.data ?: return
        if (data.scheme == "tel") {
            number = Uri.decode(data.schemeSpecificPart ?: "")
        }
    }

    private fun isDefaultDialer(): Boolean {
        val telecom = getSystemService(TelecomManager::class.java)
        return telecom?.defaultDialerPackage == packageName
    }

    private fun updateDefaultButton() {
        defaultButton.visibility = if (isDefaultDialer()) View.GONE else View.VISIBLE
    }

    private fun requestDefaultDialer() {
        val intent = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            getSystemService(RoleManager::class.java).createRequestRoleIntent(RoleManager.ROLE_DIALER)
        } else {
            Intent(TelecomManager.ACTION_CHANGE_DEFAULT_DIALER)
                .putExtra(TelecomManager.EXTRA_CHANGE_DEFAULT_DIALER_PACKAGE_NAME, packageName)
        }
        dialerRoleLauncher.launch(intent)
    }

    private fun buildKeypad(): LinearLayout {
        val grid = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        val keys = listOf(
            listOf("1", "2", "3"),
            listOf("4", "5", "6"),
            listOf("7", "8", "9"),
            listOf("*", "0", "#")
        )
        for (rowKeys in keys) {
            val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
            for (key in rowKeys) {
                val button = Button(this).apply {
                    text = key
                    textSize = 22f
                    setOnClickListener {
                        if (number.length < 15) {
                            number += key
                            render()
                        }
                    }
                }
                row.addView(button, LinearLayout.LayoutParams(
                    0, ViewGroup.LayoutParams.MATCH_PARENT, 1f))
            }
            grid.addView(row, LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f))
        }
        return grid
    }

    private fun buildSliders(): ScrollView {
        val rows = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        for (i in 0 until digitCount) {
            val label = TextView(this).apply {
                text = (i + 1).toString()
                textSize = 12f
            }
            val bar = SeekBar(this).apply {
                max = 9
                setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                    override fun onProgressChanged(seekBar: SeekBar?, progress: Int, fromUser: Boolean) {
                        if (fromUser) setDigit(i, progress)
                    }

                    override fun onStartTrackingTouch(seekBar: SeekBar?) {}
                    override fun onStopTrackingTouch(seekBar: SeekBar?) {}
                })
            }
            val value = TextView(this).apply {
                text = "-"
                textSize = 18f
                gravity = Gravity.END
            }
            val row = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER_VERTICAL
            }
            row.addView(label, LinearLayout.LayoutParams(dp(24), ViewGroup.LayoutParams.WRAP_CONTENT))
            row.addView(bar, LinearLayout.LayoutParams(0, dp(44), 1f))
            row.addView(value, LinearLayout.LayoutParams(dp(28), ViewGroup.LayoutParams.WRAP_CONTENT))
            rows.addView(row, LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
            digitBars.add(bar)
            digitValues.add(value)
        }
        return ScrollView(this).apply { addView(rows) }
    }

    private fun toggleMode() {
        sliderMode = !sliderMode
        applyMode()
        render()
    }

    private fun applyMode() {
        keypad.visibility = if (sliderMode) View.GONE else View.VISIBLE
        sliderScroll.visibility = if (sliderMode) View.VISIBLE else View.GONE
        modeButton.text = if (sliderMode) "Tuş takımı" else "Slider ile numara"
    }

    private fun digitsOnly(): String = number.filter { it.isDigit() }

    private fun setDigit(index: Int, digit: Int) {
        val digits = StringBuilder(digitsOnly())
        while (digits.length <= index) digits.append('0')
        digits.setCharAt(index, '0' + digit)
        number = digits.toString()
        render()
    }

    private fun render() {
        display.text = if (number.isEmpty()) "-" else format(number)
        val digits = digitsOnly()
        for (i in 0 until digitCount) {
            val digit = digits.getOrNull(i)
            digitBars[i].progress = digit?.digitToInt() ?: 0
            digitValues[i].text = digit?.toString() ?: "-"
        }
    }

    // 05321234567 -> 0532 123 45 67
    private fun format(text: String): String {
        if (!text.startsWith("0") || !text.all { it.isDigit() }) return text
        val groups = listOf(4, 3, 2, 2)
        val parts = ArrayList<String>()
        var start = 0
        for (size in groups) {
            if (start >= text.length) break
            val end = minOf(start + size, text.length)
            parts.add(text.substring(start, end))
            start = end
        }
        if (start < text.length) parts.add(text.substring(start))
        return parts.joinToString(" ")
    }

    private fun startCall() {
        if (number.isEmpty()) {
            toast("Önce bir numara girin")
            return
        }
        if (!isDefaultDialer()) {
            // Not the default phone app yet: hand the number to the phone's own dialer.
            open(Intent(Intent.ACTION_DIAL, Uri.fromParts("tel", number, null)))
            return
        }
        if (checkSelfPermission(Manifest.permission.CALL_PHONE) != PackageManager.PERMISSION_GRANTED) {
            callPermissionLauncher.launch(Manifest.permission.CALL_PHONE)
            return
        }
        placeCall()
    }

    private fun placeCall() {
        try {
            val telecom = getSystemService(TelecomManager::class.java)
            telecom.placeCall(Uri.fromParts("tel", number, null), Bundle())
            startActivity(Intent(this, CallActivity::class.java))
        } catch (e: SecurityException) {
            toast("Arama izni yok")
        }
    }

    private fun startMessage() {
        val recipient = number.filter { it.isDigit() || it == '+' }
        if (recipient.isEmpty()) {
            toast("Önce bir numara girin")
            return
        }
        open(Intent(Intent.ACTION_SENDTO, Uri.fromParts("smsto", recipient, null)))
    }

    private fun open(intent: Intent) {
        try {
            startActivity(intent)
        } catch (e: ActivityNotFoundException) {
            toast("Bu işlem için uygulama bulunamadı")
        }
    }
}
